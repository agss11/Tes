const fs = require("fs")
const os = require('os');

let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime }) => {
let teksnya = `
┏ ⪻ *F U N M E N U ≫*  
────────────────────  
> ╰•_.cekkontol 🍆  
> ╰•_.cekmemek 🍑  
> ╰•_.cekkhodam 👻  
> ╰•_.checkme 🤳  
> ╰•_.kontol 🍆  
> ╰•_.cabul 🔥  
> ╰•_.tolol 🤦‍♂️  
> ╰•_.goblog/goblok 🧠  
> ╰•_.idiot 🤡  
> ╰•_.gay 🏳️‍🌈  
> ╰•_.jomok 🤪  
> ╰•_.bajingan 🐒  
> ╰•_.munafik 🙄  
> ╰•_.kontol 🍆  
> ╰•_.yatim 🙋‍♂️  
> ╰•_.poke 👈  
> ╰•_.pembokep 🍑  
> ╰•_.fembokef 🍑🔥  
> ╰•_.pengocok 🍹  
> ╰•_.hitam ⚫  
> ╰•_.hytam 🖤  
> ╰•_.bego 🤦‍♀️  
> ╰•_.jawa 🌾  
> ╰•_.wibu 🥢  
> ╰•_.stress 😖  
> ╰•_.miskin 💸  
> ╰•_.cantik 💖  
> ╰•_.ganteng 😎  
> ╰•_.setan 👹  
> ╰•_.manis 🍬  
> ╰•_.babi 🐷  
> ╰•_.cina 🏮  
> ╰•_.atheis 🧘‍♂️  
> ╰•_.papua 🌴  
> ╰•_.pengentot 🔥  
> ╰•_.seksi 💋  
> ╰•_.kawai 🐰  
> ╰•_.tercindo 💔  
> ╰•_.cabul 🔥  
> ╰•_.fuckboy 😏  
> ╰•_.fuckgirl 💅  
> ╰•_.playboy 🎩  
> ╰•_.playgirl 👠  
> ╰•_.sange 🍑  
> ╰•_.hot 🔥  
> ╰•_.sangean 🍑🔥  
┗❐──≫
Semoga lebih seru dan keren 😎!
`
await Ditss.sendMessage(m.chat, {document: fs.readFileSync("./package.json"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: `${teksnya}`, fileName: `${botname2} V${global.versi}`, contextInfo: {
isForwarded: false, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.botname}`, newsletterJid: '120363314209665405@newsletter' }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender], externalAdReply: {containsAutoReply: false, thumbnail: await fs.readFileSync("./src/media/menu.jpg"), title: `© Copyright By ${namaOwner}`, 
renderLargerThumbnail: false, sourceUrl: global.linkSaluran, mediaType: 1}}}, {quoted: qtext})
}

handler.command = ["menufun", "menu fun", "funmenu"]

module.exports = handler